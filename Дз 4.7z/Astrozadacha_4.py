print('Двойная система Луман 16')

#Подключение необходимых для программы библиотек
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as anim
from scipy.integrate import odeint

# Константы
G = 6.67*10**(-11)                              #Гравитационная постоянная
Ms = 1.989*10**30                               #Масса Солнца, кг
Ma = 0.032*Ms                                   #Масса Луман А, кг
Mb = 0.027*Ms                                   #Масса Луман В, кг
T = 27.54*365*24*3600                           #Сидерический период, с

a = 3.557*1.496*10**11                          #Большая полуось системы, м
e = 0.343                                       #Эксцентриситет орбит

# Начальные параметры звёзд
a_a = (a * Ma) / (Ma + Mb)                      #Большая полуось компоненты А, м
a_b = (a * Mb) / (Ma + Mb)                      #Большая полуось компоненты B, м

# Первоначальные скорости звёзд даны на расстоянии 'а' от двух компонентов.
# Это расстояние достигается, если оба компонента находятся на расстояниях равных малым полуосям их орбит от центров их эллипсов.
# Следовательно, их скорости в этот момент противоположны и имеют только компоненту Vx.
# Компонента Vy в этот момент равна нулю.

c_a = a_a * e                                   #Фокальный параметр компоненты А, м
c_b = a_b * e                                   #Фокальный параметр компоненты В, м

b_a = (a_a**2 - c_a**2)**0.5                    #Малая полуось компоненты А, м
b_b = (a_b**2 - c_b**2)**0.5                    #Малая полуось компоненты В, м

Va = ((2 * np.pi * G) / (T * (Ma + Mb)**2))**(1/3) * Mb
Vb = ((2 * np.pi * G) / (T * (Ma + Mb)**2))**(1/3) * Ma

# Начальные изменяемые параметры объектов
# Луман А
xa_0 = -c_a
Vax_0 = -Va
ya_0 = b_a
Vay_0 = 0

# Луман B
xb_0 = c_b
Vbx_0 = Vb
yb_0 = -b_b
Vby_0 = 0

# Определяем пределы переменной величины (времени)
t = np.arange(0, T*50, 365*24*3600)

# Определение функции для системы диф. уравнений
def func(Z,t):
    (xa, Vax,
     ya, Vay,
     
     xb, Vbx,
     yb, Vby) = Z
    
    dxadt = Vax
    dVaxdt = -G*Mb*(xa-xb)/((xa-xb)**2 + (ya-yb)**2)**1.5
    dyadt = Vay
    dVaydt = -G*Mb*(ya-yb)/((xa-xb)**2 + (ya-yb)**2)**1.5
    
    dxbdt = Vbx
    dVbxdt = -G*Ma*(xb-xa)/((xb-xa)**2 + (yb-ya)**2)**1.5
    dybdt = Vby
    dVbydt = -G*Ma*(yb-ya)/((xb-xa)**2 + (yb-ya)**2)**1.5
    
    return dxadt, dVaxdt, dyadt, dVaydt, dxbdt, dVbxdt, dybdt, dVbydt

Z_0 = (xa_0, Vax_0, ya_0, Vay_0, xb_0, Vbx_0, yb_0, Vby_0)

solve_sys = odeint(func,Z_0,t)

# Модуль анимации
fig,ax = plt.subplots(figsize=(6,6), facecolor='lightgrey')

# Создание маркеров планет и объектов
Obj_A,=plt.plot([],[],marker='o',markersize=10, color='red')
Obj_B,=plt.plot([],[],marker='o',markersize=10, color='orange')

# Создание функции анимации
def animate(i):
    Obj_A.set_data(solve_sys[i,0],solve_sys[i,2])
    Obj_B.set_data(solve_sys[i,4],solve_sys[i,6])
    
    # Определение временного периода
    ax.set_title('time, year {}'.format(i))

animation = anim.FuncAnimation(fig,animate,frames=1377,interval=10)

# Украшательства
plt.grid()
plt.axis('equal')
plt.xlim(-1.2*a,1.2*a)
plt.ylim(-1.2*a,1.2*a)

# Итог
animation.save('Luman_16.gif')
     
     
     
     
     
     
